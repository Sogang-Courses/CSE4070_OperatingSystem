#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
/* prj1 신지원)  is_user_vaddr 위해 추가 */
#include "threads/vaddr.h"


static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void check_address(void *addr)
{
  if (is_kernel_vaddr(addr))
    sysExit(-1);
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  // printf ("system call!\n");
  // thread_exit ();

  /* prj1 신지원) SYS_CALL 설정 */

  switch (*(uint32_t *)(f -> esp))
    {
      case SYS_HALT:
        {
          /* prj1 신지원)  반환 주소 상관없이 종료 */
          sysHalt();
          break;
        }

      case SYS_EXIT:
        {
          /* prj1 신지원)  반환 주소가 유효한지 체크한 뒤 그 주소로 돌아감 */
          check_address(f->esp + 4);
          int address = *(uint32_t *)(f->esp + 4);
          sysExit(address);
          break;
        }
      
      case SYS_EXEC:
        {
          /* prj1 신지원)  반환 주소가 유효한지 체크한 뒤 전달된 파일 이름의 주소를 저장 */
          check_address(f->esp + 4);
          const char *file = (char *)*(uint32_t *)(f->esp + 4);
          f->eax = sysExec(file);
          break;
        }

      case SYS_WAIT:
        {
          check_address(f->esp + 4);
          pid_t pid = *(uint32_t *)(f->esp + 4);
          f->eax = sysWait(pid);
          break;
        }

      case SYS_READ:
        { 
          int fd = (int)*(uint32_t *)(f->esp + 4);
          void *buf = (void *)*(uint32_t *)(f->esp + 8);
          unsigned size = (unsigned)*(uint32_t *)(f->esp + 12);
          f->eax = sysRead(fd, buf, size);
          break;
        }

      case SYS_WRITE:
        {
          int fd = (int)*(uint32_t *)(f->esp + 4);
          const void *buf = (void *)*(uint32_t *)(f->esp + 8);
          unsigned size = (unsigned)*(uint32_t *)(f->esp + 12);
          f->eax = sysWrite(fd, buf, size);
          break;
        }

      case SYS_FIBO:
        {
          int num = (int)*(uint32_t *)(f->esp + 4);
          f->eax = sysFibo(num);
          break;
        }

      case SYS_MAX:
        {
          int a = (int)*(uint32_t *)(f->esp + 4);
          int b = (int)*(uint32_t *)(f->esp + 8);
          int c = (int)*(uint32_t *)(f->esp + 12);
          int d = (int)*(uint32_t *)(f->esp + 16);
          f->eax = sysMax(a, b, c, d);
          break;
        }
    }
}

void sysHalt()
{
  shutdown_power_off();
}

void sysExit (int status)
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_current()->exit_status = status;
  thread_exit();
}

pid_t sysExec(const char *file)
{
  return process_execute(file);
}

int sysWait(pid_t pid)
{
  return process_wait(pid);
}

int sysRead(int fd, void *buf, unsigned size)
{
  if (fd == 0)
  {
    int cnt = 0;
    while (cnt++ < (int)size)
    {
      uint8_t c = input_getc();
      if (c == '\0')
        break;
    }
    return cnt;
  } else
      return -1;
}

int sysWrite(int fd, const void *buf, unsigned size)
{
  if (fd == 1)
  {
    putbuf((char *)buf, (size_t)size);
    return size;
  } else
      return -1;
}

int sysFibo(int n)
{
    if (n <= 1)
        return n;

    int a = 0, b = 1, sum = 0;
    for (int i = 2; i <= n; i++)
    {
        sum = a + b;
        a = b;
        b = sum;
    }

    return b;
}

int sysMax(int a, int b, int c, int d)
{
  int max = (a > b) ? a : b;
  max = (max > c) ? max : c;
  max = (max > d) ? max : d;

  return max;
}
