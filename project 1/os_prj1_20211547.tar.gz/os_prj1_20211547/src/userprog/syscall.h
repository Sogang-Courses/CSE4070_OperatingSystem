#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

typedef int pid_t;

void syscall_init (void);
void check_address(void *addr);
void sysHalt(void);
void sysExit(int status);
pid_t sysExec(const char *file);
int sysWait(pid_t);
int sysRead(int fd, void *buffer, unsigned length);
int sysWrite(int fd, const void *buffer, unsigned length);
int sysFibo(int n);
int sysMax(int a, int b, int c, int d);

#endif /* userprog/syscall.h */
